# Assume the virtualenv is called .env

cp frameworkpython .env/bin
.env/bin/frameworkpython -m IPython notebook
